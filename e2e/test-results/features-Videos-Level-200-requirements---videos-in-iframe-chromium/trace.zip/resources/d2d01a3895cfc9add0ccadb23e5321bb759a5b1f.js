import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/VideoForm/VideoForm.jsx");import * as RefreshRuntime from "/@react-refresh";

if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1507d8b4"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];
import "/src/VideoForm/VideoForm.scss";
const VideoForm = ({ handleSubmit })=>{
    return /*#__PURE__*/ _jsxDEV("form", {
        onSubmit: handleSubmit,
        className: "form",
        children: [
            /*#__PURE__*/ _jsxDEV("label", {
                htmlFor: "title",
                className: "form__label",
                children: [
                    "Title",
                    /*#__PURE__*/ _jsxDEV("input", {
                        type: "text",
                        name: "title",
                        className: "form__input",
                        required: true
                    }, void 0, false, {
                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx",
                        lineNumber: 7,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx",
                lineNumber: 5,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ _jsxDEV("label", {
                htmlFor: "URL",
                className: "form__label",
                children: [
                    "URL",
                    /*#__PURE__*/ _jsxDEV("input", {
                        type: "text",
                        name: "src",
                        className: "form__input",
                        required: true
                    }, void 0, false, {
                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx",
                        lineNumber: 11,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx",
                lineNumber: 9,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ _jsxDEV("button", {
                type: "submit",
                className: "form__btn",
                children: "Submit"
            }, void 0, false, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx",
                lineNumber: 13,
                columnNumber: 4
            }, this)
        ]
    }, void 0, true, {
        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx",
        lineNumber: 4,
        columnNumber: 3
    }, this);
};
_c = VideoForm;
export default VideoForm;
var _c;
$RefreshReg$(_c, "VideoForm");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;
RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/VideoForm/VideoForm.jsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlZpZGVvRm9ybS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi9WaWRlb0Zvcm0uc2Nzc1wiO1xuY29uc3QgVmlkZW9Gb3JtID0gKHsgaGFuZGxlU3VibWl0IH0pID0+IHtcblx0cmV0dXJuIChcblx0XHQ8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJmb3JtXCI+XG4gICAgICA8bGFiZWwgaHRtbEZvcj1cInRpdGxlXCIgY2xhc3NOYW1lPVwiZm9ybV9fbGFiZWxcIj5cblx0XHRcdFx0VGl0bGVcblx0XHRcdFx0PGlucHV0IHR5cGU9XCJ0ZXh0XCIgbmFtZT1cInRpdGxlXCIgY2xhc3NOYW1lPVwiZm9ybV9faW5wdXRcIiByZXF1aXJlZCAvPlxuXHRcdFx0PC9sYWJlbD5cblx0XHRcdDxsYWJlbCBodG1sRm9yPVwiVVJMXCIgY2xhc3NOYW1lPVwiZm9ybV9fbGFiZWxcIj5cblx0XHRcdFx0VVJMXG5cdFx0XHRcdDxpbnB1dCB0eXBlPVwidGV4dFwiIG5hbWU9XCJzcmNcIiBjbGFzc05hbWU9XCJmb3JtX19pbnB1dFwiIHJlcXVpcmVkIC8+XG5cdFx0XHQ8L2xhYmVsPlxuXHRcdFx0PGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwiZm9ybV9fYnRuXCI+XG5cdFx0XHRcdFN1Ym1pdFxuXHRcdFx0PC9idXR0b24+XG5cdFx0PC9mb3JtPlxuXHQpO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVmlkZW9Gb3JtO1xuIl0sIm5hbWVzIjpbIlZpZGVvRm9ybSIsImhhbmRsZVN1Ym1pdCIsImZvcm0iLCJvblN1Ym1pdCIsImNsYXNzTmFtZSIsImxhYmVsIiwiaHRtbEZvciIsImlucHV0IiwidHlwZSIsIm5hbWUiLCJyZXF1aXJlZCIsImJ1dHRvbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsT0FBTyxtQkFBbUI7QUFDMUIsTUFBTUEsWUFBWSxDQUFDLEVBQUVDLFlBQVksRUFBRTtJQUNsQyxxQkFDQyxRQUFDQztRQUFLQyxVQUFVRjtRQUFjRyxXQUFVOzswQkFDcEMsUUFBQ0M7Z0JBQU1DLFNBQVE7Z0JBQVFGLFdBQVU7O29CQUFjO2tDQUVqRCxRQUFDRzt3QkFBTUMsTUFBSzt3QkFBT0MsTUFBSzt3QkFBUUwsV0FBVTt3QkFBY00sUUFBUTs7Ozs7Ozs7Ozs7OzBCQUVqRSxRQUFDTDtnQkFBTUMsU0FBUTtnQkFBTUYsV0FBVTs7b0JBQWM7a0NBRTVDLFFBQUNHO3dCQUFNQyxNQUFLO3dCQUFPQyxNQUFLO3dCQUFNTCxXQUFVO3dCQUFjTSxRQUFROzs7Ozs7Ozs7Ozs7MEJBRS9ELFFBQUNDO2dCQUFPSCxNQUFLO2dCQUFTSixXQUFVOzBCQUFZOzs7Ozs7Ozs7Ozs7QUFLL0M7S0FoQk1KO0FBa0JOLGVBQWVBLFVBQVUifQ==