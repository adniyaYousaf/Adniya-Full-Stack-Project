import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/Videos/Videos.jsx");import * as RefreshRuntime from "/@react-refresh";

if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1507d8b4"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
import { FaThumbsDown, FaThumbsUp } from "/node_modules/.vite/deps/react-icons_fa.js?v=1507d8b4";
import { FaHeart } from "/node_modules/.vite/deps/react-icons_fa.js?v=1507d8b4";
import "/src/Videos/videos.scss";
const formatDate = (d)=>{
    let date = new Date(d);
    return date.toDateString();
};
const Videos = (props)=>{
    const mapVideos = props.video.map((video, index)=>{
        return /*#__PURE__*/ _jsxDEV("div", {
            className: "container",
            children: [
                /*#__PURE__*/ _jsxDEV("iframe", {
                    src: video.src,
                    title: "Video recommendations",
                    className: "container_video"
                }, void 0, false, {
                    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                    lineNumber: 14,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "container_btns",
                    children: [
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "container_btns_time",
                            children: /*#__PURE__*/ _jsxDEV("p", {
                                children: [
                                    /*#__PURE__*/ _jsxDEV("strong", {
                                        children: "Time:"
                                    }, void 0, false, {
                                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                        lineNumber: 22,
                                        columnNumber: 8
                                    }, this),
                                    /*#__PURE__*/ _jsxDEV("span", {
                                        children: [
                                            " ",
                                            formatDate(video.addeddate)
                                        ]
                                    }, void 0, true, {
                                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                        lineNumber: 22,
                                        columnNumber: 30
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                lineNumber: 21,
                                columnNumber: 7
                            }, this)
                        }, void 0, false, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                            lineNumber: 20,
                            columnNumber: 6
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "container_btns_thumb-box",
                            children: [
                                "Up Vote",
                                /*#__PURE__*/ _jsxDEV(FaThumbsUp, {
                                    className: "container_btns_thumb-box_thumb",
                                    onClick: ()=>props.update(video.id, "up")
                                }, void 0, false, {
                                    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                    lineNumber: 26,
                                    columnNumber: 14
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                            lineNumber: 25,
                            columnNumber: 6
                        }, this),
                        /*#__PURE__*/ _jsxDEV("div", {
                            className: "container_btns_thumb-box",
                            children: [
                                "Down Vote",
                                /*#__PURE__*/ _jsxDEV(FaThumbsDown, {
                                    className: "container_btns_thumb-box_thumb",
                                    onClick: ()=>props.update(video.id, "down")
                                }, void 0, false, {
                                    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                    lineNumber: 32,
                                    columnNumber: 16
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                            lineNumber: 31,
                            columnNumber: 6
                        }, this),
                        /*#__PURE__*/ _jsxDEV("button", {
                            className: "container_btns_delbtn",
                            onClick: ()=>props.click(video.id),
                            children: "Remove video"
                        }, void 0, false, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                            lineNumber: 37,
                            columnNumber: 6
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                    lineNumber: 19,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ _jsxDEV("div", {
                    className: "container_title",
                    children: [
                        /*#__PURE__*/ _jsxDEV("p", {
                            children: video.title
                        }, void 0, false, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                            lineNumber: 45,
                            columnNumber: 6
                        }, this),
                        /*#__PURE__*/ _jsxDEV("p", {
                            className: "container_title_rating",
                            children: [
                                "Rating ",
                                video.rating,
                                /*#__PURE__*/ _jsxDEV("span", {
                                    children: /*#__PURE__*/ _jsxDEV(FaHeart, {}, void 0, false, {
                                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                        lineNumber: 49,
                                        columnNumber: 8
                                    }, this)
                                }, void 0, false, {
                                    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                                    lineNumber: 48,
                                    columnNumber: 7
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                            lineNumber: 46,
                            columnNumber: 6
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
                    lineNumber: 44,
                    columnNumber: 5
                }, this)
            ]
        }, index, true, {
            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
            lineNumber: 13,
            columnNumber: 4
        }, this);
    });
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: /*#__PURE__*/ _jsxDEV("div", {
            className: "container-box",
            children: mapVideos
        }, void 0, false, {
            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx",
            lineNumber: 59,
            columnNumber: 4
        }, this)
    }, void 0, false);
};
_c = Videos;
export default Videos;
var _c;
$RefreshReg$(_c, "Videos");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;
RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/Videos/Videos.jsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIlZpZGVvcy5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRmFUaHVtYnNEb3duLCBGYVRodW1ic1VwIH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XG5pbXBvcnQgeyBGYUhlYXJ0IH0gZnJvbSBcInJlYWN0LWljb25zL2ZhXCI7XG5pbXBvcnQgXCIuL3ZpZGVvcy5zY3NzXCI7XG5cbmNvbnN0IGZvcm1hdERhdGUgPSAoZCkgPT4ge1xuXHRsZXQgZGF0ZSA9IG5ldyBEYXRlKGQpO1xuXHRyZXR1cm4gZGF0ZS50b0RhdGVTdHJpbmcoKTtcbn07XG5cbmNvbnN0IFZpZGVvcyA9IChwcm9wcykgPT4ge1xuXHRjb25zdCBtYXBWaWRlb3MgPSBwcm9wcy52aWRlby5tYXAoKHZpZGVvLCBpbmRleCkgPT4ge1xuXHRcdHJldHVybiAoXG5cdFx0XHQ8ZGl2IGtleT17aW5kZXh9IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxuXHRcdFx0XHQ8aWZyYW1lXG5cdFx0XHRcdFx0c3JjPXt2aWRlby5zcmN9XG5cdFx0XHRcdFx0dGl0bGU9XCJWaWRlbyByZWNvbW1lbmRhdGlvbnNcIlxuXHRcdFx0XHRcdGNsYXNzTmFtZT1cImNvbnRhaW5lcl92aWRlb1wiXG5cdFx0XHRcdD48L2lmcmFtZT5cblx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJfYnRuc1wiPlxuXHRcdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyX2J0bnNfdGltZVwiPlxuXHRcdFx0XHRcdFx0PHA+XG5cdFx0XHRcdFx0XHRcdDxzdHJvbmc+VGltZTo8L3N0cm9uZz48c3Bhbj4ge2Zvcm1hdERhdGUodmlkZW8uYWRkZWRkYXRlKX08L3NwYW4+XG5cdFx0XHRcdFx0XHQ8L3A+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJfYnRuc190aHVtYi1ib3hcIj5cblx0XHRcdFx0XHRcdFVwIFZvdGU8RmFUaHVtYnNVcFxuXHRcdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJjb250YWluZXJfYnRuc190aHVtYi1ib3hfdGh1bWJcIlxuXHRcdFx0XHRcdFx0XHRvbkNsaWNrPXsoKSA9PiBwcm9wcy51cGRhdGUodmlkZW8uaWQsIFwidXBcIil9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyX2J0bnNfdGh1bWItYm94XCI+XG5cdFx0XHRcdFx0XHREb3duIFZvdGU8RmFUaHVtYnNEb3duXG5cdFx0XHRcdFx0XHRcdGNsYXNzTmFtZT1cImNvbnRhaW5lcl9idG5zX3RodW1iLWJveF90aHVtYlwiXG5cdFx0XHRcdFx0XHRcdG9uQ2xpY2s9eygpID0+IHByb3BzLnVwZGF0ZSh2aWRlby5pZCwgXCJkb3duXCIpfVxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRjbGFzc05hbWU9XCJjb250YWluZXJfYnRuc19kZWxidG5cIlxuXHRcdFx0XHRcdFx0b25DbGljaz17KCkgPT4gcHJvcHMuY2xpY2sodmlkZW8uaWQpfVxuXHRcdFx0XHRcdD5cblx0XHRcdFx0XHRcdFJlbW92ZSB2aWRlb1xuXHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJfdGl0bGVcIj5cblx0XHRcdFx0XHQ8cCA+e3ZpZGVvLnRpdGxlfTwvcD5cblx0XHRcdFx0XHQ8cCBjbGFzc05hbWU9XCJjb250YWluZXJfdGl0bGVfcmF0aW5nXCI+XG5cdFx0XHRcdFx0XHRSYXRpbmcge3ZpZGVvLnJhdGluZ31cblx0XHRcdFx0XHRcdDxzcGFuPlxuXHRcdFx0XHRcdFx0XHQ8RmFIZWFydCAvPlxuXHRcdFx0XHRcdFx0PC9zcGFuPlxuXHRcdFx0XHRcdDwvcD5cblx0XHRcdFx0PC9kaXY+XG5cdFx0XHQ8L2Rpdj5cblx0XHQpO1xuXHR9KTtcblxuXHRyZXR1cm4gKFxuXHRcdDw+XG5cdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lci1ib3hcIj57bWFwVmlkZW9zfTwvZGl2PlxuXHRcdDwvPlxuXHQpO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgVmlkZW9zO1xuIl0sIm5hbWVzIjpbIkZhVGh1bWJzRG93biIsIkZhVGh1bWJzVXAiLCJGYUhlYXJ0IiwiZm9ybWF0RGF0ZSIsImQiLCJkYXRlIiwiRGF0ZSIsInRvRGF0ZVN0cmluZyIsIlZpZGVvcyIsInByb3BzIiwibWFwVmlkZW9zIiwidmlkZW8iLCJtYXAiLCJpbmRleCIsImRpdiIsImNsYXNzTmFtZSIsImlmcmFtZSIsInNyYyIsInRpdGxlIiwicCIsInN0cm9uZyIsInNwYW4iLCJhZGRlZGRhdGUiLCJvbkNsaWNrIiwidXBkYXRlIiwiaWQiLCJidXR0b24iLCJjbGljayIsInJhdGluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEsU0FBU0EsWUFBWSxFQUFFQyxVQUFVLFFBQVEsaUJBQWlCO0FBQzFELFNBQVNDLE9BQU8sUUFBUSxpQkFBaUI7QUFDekMsT0FBTyxnQkFBZ0I7QUFFdkIsTUFBTUMsYUFBYSxDQUFDQztJQUNuQixJQUFJQyxPQUFPLElBQUlDLEtBQUtGO0lBQ3BCLE9BQU9DLEtBQUtFLFlBQVk7QUFDekI7QUFFQSxNQUFNQyxTQUFTLENBQUNDO0lBQ2YsTUFBTUMsWUFBWUQsTUFBTUUsS0FBSyxDQUFDQyxHQUFHLENBQUMsQ0FBQ0QsT0FBT0U7UUFDekMscUJBQ0MsUUFBQ0M7WUFBZ0JDLFdBQVU7OzhCQUMxQixRQUFDQztvQkFDQUMsS0FBS04sTUFBTU0sR0FBRztvQkFDZEMsT0FBTTtvQkFDTkgsV0FBVTs7Ozs7OzhCQUVYLFFBQUNEO29CQUFJQyxXQUFVOztzQ0FDZCxRQUFDRDs0QkFBSUMsV0FBVTtzQ0FDZCxjQUFBLFFBQUNJOztrREFDQSxRQUFDQztrREFBTzs7Ozs7O2tEQUFjLFFBQUNDOzs0Q0FBSzs0Q0FBRWxCLFdBQVdRLE1BQU1XLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7OztzQ0FHMUQsUUFBQ1I7NEJBQUlDLFdBQVU7O2dDQUEyQjs4Q0FDbEMsUUFBQ2Q7b0NBQ1BjLFdBQVU7b0NBQ1ZRLFNBQVMsSUFBTWQsTUFBTWUsTUFBTSxDQUFDYixNQUFNYyxFQUFFLEVBQUU7Ozs7Ozs7Ozs7OztzQ0FHeEMsUUFBQ1g7NEJBQUlDLFdBQVU7O2dDQUEyQjs4Q0FDaEMsUUFBQ2Y7b0NBQ1RlLFdBQVU7b0NBQ1ZRLFNBQVMsSUFBTWQsTUFBTWUsTUFBTSxDQUFDYixNQUFNYyxFQUFFLEVBQUU7Ozs7Ozs7Ozs7OztzQ0FHeEMsUUFBQ0M7NEJBQ0FYLFdBQVU7NEJBQ1ZRLFNBQVMsSUFBTWQsTUFBTWtCLEtBQUssQ0FBQ2hCLE1BQU1jLEVBQUU7c0NBQ25DOzs7Ozs7Ozs7Ozs7OEJBSUYsUUFBQ1g7b0JBQUlDLFdBQVU7O3NDQUNkLFFBQUNJO3NDQUFJUixNQUFNTyxLQUFLOzs7Ozs7c0NBQ2hCLFFBQUNDOzRCQUFFSixXQUFVOztnQ0FBeUI7Z0NBQzdCSixNQUFNaUIsTUFBTTs4Q0FDcEIsUUFBQ1A7OENBQ0EsY0FBQSxRQUFDbkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBcENLVzs7Ozs7SUEwQ1o7SUFFQSxxQkFDQztrQkFDQyxjQUFBLFFBQUNDO1lBQUlDLFdBQVU7c0JBQWlCTDs7Ozs7OztBQUduQztLQXBETUY7QUFzRE4sZUFBZUEsT0FBTyJ9