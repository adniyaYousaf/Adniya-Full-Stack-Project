import {
  require_react
} from "/node_modules/.vite/deps/chunk-UWMVR7AD.js?v=1507d8b4";
export default require_react();
//# sourceMappingURL=react.js.map
