import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1507d8b4"; const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=1507d8b4"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=1507d8b4"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import { BrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=1507d8b4";
import App from "/src/App.jsx?t=1718394013397";
import "/src/index.css";
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/ _jsxDEV(React.StrictMode, {
    children: /*#__PURE__*/ _jsxDEV(BrowserRouter, {
        children: /*#__PURE__*/ _jsxDEV(App, {}, void 0, false, {
            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/index.jsx",
            lineNumber: 11,
            columnNumber: 4
        }, this)
    }, void 0, false, {
        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/index.jsx",
        lineNumber: 10,
        columnNumber: 3
    }, this)
}, void 0, false, {
    fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/index.jsx",
    lineNumber: 9,
    columnNumber: 2
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbS9jbGllbnRcIjtcbmltcG9ydCB7IEJyb3dzZXJSb3V0ZXIgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xuXG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcC5qc3hcIjtcbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyb290XCIpKS5yZW5kZXIoXG5cdDxSZWFjdC5TdHJpY3RNb2RlPlxuXHRcdDxCcm93c2VyUm91dGVyPlxuXHRcdFx0PEFwcCAvPlxuXHRcdDwvQnJvd3NlclJvdXRlcj5cblx0PC9SZWFjdC5TdHJpY3RNb2RlPlxuKTtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIlJlYWN0RE9NIiwiQnJvd3NlclJvdXRlciIsIkFwcCIsImNyZWF0ZVJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIiwiU3RyaWN0TW9kZSJdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU9BLFdBQVcsUUFBUTtBQUMxQixPQUFPQyxjQUFjLG1CQUFtQjtBQUN4QyxTQUFTQyxhQUFhLFFBQVEsbUJBQW1CO0FBRWpELE9BQU9DLFNBQVMsWUFBWTtBQUM1QixPQUFPLGNBQWM7QUFFckJGLFNBQVNHLFVBQVUsQ0FBQ0MsU0FBU0MsY0FBYyxDQUFDLFNBQVNDLE1BQU0sZUFDMUQsUUFBQ1AsTUFBTVEsVUFBVTtjQUNoQixjQUFBLFFBQUNOO2tCQUNBLGNBQUEsUUFBQ0MifQ==