import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import * as RefreshRuntime from "/@react-refresh";

if (!window.$RefreshReg$) throw new Error("React refresh preamble was not loaded. Something is wrong.");
const prevRefreshReg = window.$RefreshReg$;
const prevRefreshSig = window.$RefreshSig$;
window.$RefreshReg$ = RefreshRuntime.getRefreshReg("/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx");
window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;

import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1507d8b4"; const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];
var _s = $RefreshSig$();
import Videos from "/src/Videos/Videos.jsx?t=1718394013397";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=1507d8b4"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import VideoForm from "/src/VideoForm/VideoForm.jsx?t=1718392985535";
import { FaSortDown } from "/node_modules/.vite/deps/react-icons_fa6.js?v=1507d8b4";
import { FaSortUp } from "/node_modules/.vite/deps/react-icons_fa.js?v=1507d8b4";
import "/src/App.scss";
const App = ()=>{
    _s();
    const [videos, setVideos] = useState([]);
    const [fetchedVideos, setFetchedVideos] = useState(true);
    useEffect(()=>{
        if (fetchedVideos) {
            fetch("/api/videos").then((res)=>res.json()).then((data)=>{
                setVideos(data);
            });
            setFetchedVideos(false);
        }
    }, [
        fetchedVideos
    ]);
    const handleSort = async (sort)=>{
        await fetch(`/api/videos/${sort}`).then((res)=>res.json()).then((data)=>{
            setVideos(data);
        });
        setFetchedVideos(false);
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        const formData = Object.fromEntries(new FormData(e.target));
        const response = await fetch("/api/videos", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(formData)
        });
        if (response.ok) {
            setFetchedVideos(true);
        }
        if (!response.ok) {
            throw new Error("Failed to add video");
        }
        const responseData = await response.json();
        e.target.reset();
    };
    const handleDelete = async (id)=>{
        const response = await fetch(`/api/videos/${id}`, {
            method: "DELETE"
        });
        if (!response.ok) {
            console.log("Could not delete the video.");
        }
        setFetchedVideos(true);
    };
    const handleUpdate = async (id, vote)=>{
        let response = await fetch(`/api/videos/${id}/${vote}`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            }
        });
        if (response.ok) {
            setFetchedVideos(true);
        }
    };
    return /*#__PURE__*/ _jsxDEV(_Fragment, {
        children: [
            /*#__PURE__*/ _jsxDEV("h1", {
                children: "Video Recommendations"
            }, void 0, false, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                lineNumber: 79,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "sort",
                children: [
                    /*#__PURE__*/ _jsxDEV("button", {
                        className: "sort_btn",
                        children: /*#__PURE__*/ _jsxDEV(FaSortUp, {
                            onClick: ()=>handleSort("asc")
                        }, void 0, false, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                            lineNumber: 82,
                            columnNumber: 6
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                        lineNumber: 81,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ _jsxDEV("button", {
                        className: "sort_btn",
                        children: /*#__PURE__*/ _jsxDEV(FaSortDown, {
                            onClick: ()=>handleSort("desc")
                        }, void 0, false, {
                            fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                            lineNumber: 85,
                            columnNumber: 6
                        }, this)
                    }, void 0, false, {
                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                        lineNumber: 84,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                lineNumber: 80,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ _jsxDEV(Videos, {
                video: videos,
                update: handleUpdate,
                click: handleDelete
            }, void 0, false, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                lineNumber: 88,
                columnNumber: 4
            }, this),
            /*#__PURE__*/ _jsxDEV("div", {
                className: "form-box",
                children: [
                    /*#__PURE__*/ _jsxDEV(VideoForm, {
                        handleSubmit: handleSubmit
                    }, void 0, false, {
                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                        lineNumber: 90,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ _jsxDEV("div", {
                        className: "form-box_heading",
                        children: "Add Recommendations here!!"
                    }, void 0, false, {
                        fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                        lineNumber: 91,
                        columnNumber: 5
                    }, this)
                ]
            }, void 0, true, {
                fileName: "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx",
                lineNumber: 89,
                columnNumber: 4
            }, this)
        ]
    }, void 0, true);
};
_s(App, "DVUtUaHDaF4Ar01vHTtwPrZ4xMg=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");


window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;
RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
  RefreshRuntime.registerExportsForReactRefresh("/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/App.jsx", currentExports);
  import.meta.hot.accept((nextExports) => {
    if (!nextExports) return;
    const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
    if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
  });
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFZpZGVvcyBmcm9tIFwiLi9WaWRlb3MvVmlkZW9zXCI7XG5pbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgVmlkZW9Gb3JtIGZyb20gXCIuL1ZpZGVvRm9ybS9WaWRlb0Zvcm1cIjtcbmltcG9ydCB7IEZhU29ydERvd24gfSBmcm9tIFwicmVhY3QtaWNvbnMvZmE2XCI7XG5pbXBvcnQgeyBGYVNvcnRVcCB9IGZyb20gXCJyZWFjdC1pY29ucy9mYVwiO1xuaW1wb3J0IFwiLi9BcHAuc2Nzc1wiO1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG5cdGNvbnN0IFt2aWRlb3MsIHNldFZpZGVvc10gPSB1c2VTdGF0ZShbXSk7XG5cdGNvbnN0IFtmZXRjaGVkVmlkZW9zLCBzZXRGZXRjaGVkVmlkZW9zXSA9IHVzZVN0YXRlKHRydWUpO1xuXG5cdHVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGZldGNoZWRWaWRlb3MpIHtcblx0XHRcdGZldGNoKFwiL2FwaS92aWRlb3NcIilcblx0XHRcdFx0LnRoZW4oKHJlcykgPT4gcmVzLmpzb24oKSlcblx0XHRcdFx0LnRoZW4oKGRhdGEpID0+IHtcblx0XHRcdFx0XHRzZXRWaWRlb3MoZGF0YSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0c2V0RmV0Y2hlZFZpZGVvcyhmYWxzZSk7XG5cdFx0fVxuXHR9LCBbZmV0Y2hlZFZpZGVvc10pO1xuXG5cdGNvbnN0IGhhbmRsZVNvcnQgPSBhc3luYyAoc29ydCkgPT4ge1xuXHRcdGF3YWl0IGZldGNoKGAvYXBpL3ZpZGVvcy8ke3NvcnR9YClcblx0XHRcdC50aGVuKChyZXMpID0+IHJlcy5qc29uKCkpXG5cdFx0XHQudGhlbigoZGF0YSkgPT4ge1xuXHRcdFx0XHRzZXRWaWRlb3MoZGF0YSk7XG5cdFx0XHR9KTtcblx0XHRzZXRGZXRjaGVkVmlkZW9zKGZhbHNlKTtcblx0fTtcblxuXHRjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZSkgPT4ge1xuXHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHRjb25zdCBmb3JtRGF0YSA9IE9iamVjdC5mcm9tRW50cmllcyhuZXcgRm9ybURhdGEoZS50YXJnZXQpKTtcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFwiL2FwaS92aWRlb3NcIiwge1xuXHRcdFx0bWV0aG9kOiBcIlBPU1RcIixcblx0XHRcdGhlYWRlcnM6IHtcblx0XHRcdFx0XCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG5cdFx0XHR9LFxuXHRcdFx0Ym9keTogSlNPTi5zdHJpbmdpZnkoZm9ybURhdGEpLFxuXHRcdH0pO1xuXG5cdFx0aWYgKHJlc3BvbnNlLm9rKSB7XG5cdFx0XHRzZXRGZXRjaGVkVmlkZW9zKHRydWUpO1xuXHRcdH1cblxuXHRcdGlmICghcmVzcG9uc2Uub2spIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBhZGQgdmlkZW9cIik7XG5cdFx0fVxuXG5cdFx0Y29uc3QgcmVzcG9uc2VEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuXHRcdGUudGFyZ2V0LnJlc2V0KCk7XG5cdH07XG5cblx0Y29uc3QgaGFuZGxlRGVsZXRlID0gYXN5bmMgKGlkKSA9PiB7XG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgL2FwaS92aWRlb3MvJHtpZH1gLCB7XG5cdFx0XHRtZXRob2Q6IFwiREVMRVRFXCIsXG5cdFx0fSk7XG5cdFx0aWYgKCFyZXNwb25zZS5vaykge1xuXHRcdFx0Y29uc29sZS5sb2coXCJDb3VsZCBub3QgZGVsZXRlIHRoZSB2aWRlby5cIik7XG5cdFx0fVxuXHRcdHNldEZldGNoZWRWaWRlb3ModHJ1ZSk7XG5cdH07XG5cblx0Y29uc3QgaGFuZGxlVXBkYXRlID0gYXN5bmMgKGlkLCB2b3RlKSA9PiB7XG5cdFx0bGV0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYC9hcGkvdmlkZW9zLyR7aWR9LyR7dm90ZX1gLCB7XG5cdFx0XHRtZXRob2Q6IFwiUE9TVFwiLFxuXHRcdFx0aGVhZGVyczoge1xuXHRcdFx0XHRcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIixcblx0XHRcdH0sXG5cdFx0fSk7XG5cdFx0aWYgKHJlc3BvbnNlLm9rKSB7XG5cdFx0XHRzZXRGZXRjaGVkVmlkZW9zKHRydWUpO1xuXHRcdH1cblx0fTtcblxuXHRyZXR1cm4gKFxuXHRcdDw+XG5cdFx0XHQ8aDE+VmlkZW8gUmVjb21tZW5kYXRpb25zPC9oMT5cblx0XHRcdDxkaXYgY2xhc3NOYW1lPVwic29ydFwiPlxuXHRcdFx0XHQ8YnV0dG9uIGNsYXNzTmFtZT1cInNvcnRfYnRuXCI+XG5cdFx0XHRcdFx0PEZhU29ydFVwIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNvcnQoXCJhc2NcIil9IC8+XG5cdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHQ8YnV0dG9uIGNsYXNzTmFtZT1cInNvcnRfYnRuXCI+XG5cdFx0XHRcdFx0PEZhU29ydERvd24gb25DbGljaz17KCkgPT4gaGFuZGxlU29ydChcImRlc2NcIil9IC8+XG5cdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0PC9kaXY+XG5cdFx0XHQ8VmlkZW9zIHZpZGVvPXt2aWRlb3N9IHVwZGF0ZT17aGFuZGxlVXBkYXRlfSBjbGljaz17aGFuZGxlRGVsZXRlfSAvPlxuXHRcdFx0PGRpdiBjbGFzc05hbWU9XCJmb3JtLWJveFwiPlxuXHRcdFx0XHQ8VmlkZW9Gb3JtIGhhbmRsZVN1Ym1pdD17aGFuZGxlU3VibWl0fSAvPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cImZvcm0tYm94X2hlYWRpbmdcIj5BZGQgUmVjb21tZW5kYXRpb25zIGhlcmUhITwvZGl2PlxuXHRcdFx0PC9kaXY+XG5cdFx0PC8+XG5cdCk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBBcHA7XG4iXSwibmFtZXMiOlsiVmlkZW9zIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJWaWRlb0Zvcm0iLCJGYVNvcnREb3duIiwiRmFTb3J0VXAiLCJBcHAiLCJ2aWRlb3MiLCJzZXRWaWRlb3MiLCJmZXRjaGVkVmlkZW9zIiwic2V0RmV0Y2hlZFZpZGVvcyIsImZldGNoIiwidGhlbiIsInJlcyIsImpzb24iLCJkYXRhIiwiaGFuZGxlU29ydCIsInNvcnQiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJmb3JtRGF0YSIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwiRm9ybURhdGEiLCJ0YXJnZXQiLCJyZXNwb25zZSIsIm1ldGhvZCIsImhlYWRlcnMiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsIm9rIiwiRXJyb3IiLCJyZXNwb25zZURhdGEiLCJyZXNldCIsImhhbmRsZURlbGV0ZSIsImlkIiwiY29uc29sZSIsImxvZyIsImhhbmRsZVVwZGF0ZSIsInZvdGUiLCJoMSIsImRpdiIsImNsYXNzTmFtZSIsImJ1dHRvbiIsIm9uQ2xpY2siLCJ2aWRlbyIsInVwZGF0ZSIsImNsaWNrIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQUEsT0FBT0EsWUFBWSxrQkFBa0I7QUFDckMsU0FBU0MsUUFBUSxFQUFFQyxTQUFTLFFBQVEsUUFBUTtBQUM1QyxPQUFPQyxlQUFlLHdCQUF3QjtBQUM5QyxTQUFTQyxVQUFVLFFBQVEsa0JBQWtCO0FBQzdDLFNBQVNDLFFBQVEsUUFBUSxpQkFBaUI7QUFDMUMsT0FBTyxhQUFhO0FBRXBCLE1BQU1DLE1BQU07O0lBQ1gsTUFBTSxDQUFDQyxRQUFRQyxVQUFVLEdBQUdQLFNBQVMsRUFBRTtJQUN2QyxNQUFNLENBQUNRLGVBQWVDLGlCQUFpQixHQUFHVCxTQUFTO0lBRW5EQyxVQUFVO1FBQ1QsSUFBSU8sZUFBZTtZQUNsQkUsTUFBTSxlQUNKQyxJQUFJLENBQUMsQ0FBQ0MsTUFBUUEsSUFBSUMsSUFBSSxJQUN0QkYsSUFBSSxDQUFDLENBQUNHO2dCQUNOUCxVQUFVTztZQUNYO1lBQ0RMLGlCQUFpQjtRQUNsQjtJQUNELEdBQUc7UUFBQ0Q7S0FBYztJQUVsQixNQUFNTyxhQUFhLE9BQU9DO1FBQ3pCLE1BQU1OLE1BQU0sQ0FBQyxZQUFZLEVBQUVNLEtBQUssQ0FBQyxFQUMvQkwsSUFBSSxDQUFDLENBQUNDLE1BQVFBLElBQUlDLElBQUksSUFDdEJGLElBQUksQ0FBQyxDQUFDRztZQUNOUCxVQUFVTztRQUNYO1FBQ0RMLGlCQUFpQjtJQUNsQjtJQUVBLE1BQU1RLGVBQWUsT0FBT0M7UUFDM0JBLEVBQUVDLGNBQWM7UUFDaEIsTUFBTUMsV0FBV0MsT0FBT0MsV0FBVyxDQUFDLElBQUlDLFNBQVNMLEVBQUVNLE1BQU07UUFDekQsTUFBTUMsV0FBVyxNQUFNZixNQUFNLGVBQWU7WUFDM0NnQixRQUFRO1lBQ1JDLFNBQVM7Z0JBQ1IsZ0JBQWdCO1lBQ2pCO1lBQ0FDLE1BQU1DLEtBQUtDLFNBQVMsQ0FBQ1Y7UUFDdEI7UUFFQSxJQUFJSyxTQUFTTSxFQUFFLEVBQUU7WUFDaEJ0QixpQkFBaUI7UUFDbEI7UUFFQSxJQUFJLENBQUNnQixTQUFTTSxFQUFFLEVBQUU7WUFDakIsTUFBTSxJQUFJQyxNQUFNO1FBQ2pCO1FBRUEsTUFBTUMsZUFBZSxNQUFNUixTQUFTWixJQUFJO1FBQ3hDSyxFQUFFTSxNQUFNLENBQUNVLEtBQUs7SUFDZjtJQUVBLE1BQU1DLGVBQWUsT0FBT0M7UUFDM0IsTUFBTVgsV0FBVyxNQUFNZixNQUFNLENBQUMsWUFBWSxFQUFFMEIsR0FBRyxDQUFDLEVBQUU7WUFDakRWLFFBQVE7UUFDVDtRQUNBLElBQUksQ0FBQ0QsU0FBU00sRUFBRSxFQUFFO1lBQ2pCTSxRQUFRQyxHQUFHLENBQUM7UUFDYjtRQUNBN0IsaUJBQWlCO0lBQ2xCO0lBRUEsTUFBTThCLGVBQWUsT0FBT0gsSUFBSUk7UUFDL0IsSUFBSWYsV0FBVyxNQUFNZixNQUFNLENBQUMsWUFBWSxFQUFFMEIsR0FBRyxDQUFDLEVBQUVJLEtBQUssQ0FBQyxFQUFFO1lBQ3ZEZCxRQUFRO1lBQ1JDLFNBQVM7Z0JBQ1IsZ0JBQWdCO1lBQ2pCO1FBQ0Q7UUFDQSxJQUFJRixTQUFTTSxFQUFFLEVBQUU7WUFDaEJ0QixpQkFBaUI7UUFDbEI7SUFDRDtJQUVBLHFCQUNDOzswQkFDQyxRQUFDZ0M7MEJBQUc7Ozs7OzswQkFDSixRQUFDQztnQkFBSUMsV0FBVTs7a0NBQ2QsUUFBQ0M7d0JBQU9ELFdBQVU7a0NBQ2pCLGNBQUEsUUFBQ3ZDOzRCQUFTeUMsU0FBUyxJQUFNOUIsV0FBVzs7Ozs7Ozs7Ozs7a0NBRXJDLFFBQUM2Qjt3QkFBT0QsV0FBVTtrQ0FDakIsY0FBQSxRQUFDeEM7NEJBQVcwQyxTQUFTLElBQU05QixXQUFXOzs7Ozs7Ozs7Ozs7Ozs7OzswQkFHeEMsUUFBQ2hCO2dCQUFPK0MsT0FBT3hDO2dCQUFReUMsUUFBUVI7Z0JBQWNTLE9BQU9iOzs7Ozs7MEJBQ3BELFFBQUNPO2dCQUFJQyxXQUFVOztrQ0FDZCxRQUFDekM7d0JBQVVlLGNBQWNBOzs7Ozs7a0NBQ3pCLFFBQUN5Qjt3QkFBSUMsV0FBVTtrQ0FBbUI7Ozs7Ozs7Ozs7Ozs7O0FBSXRDO0dBdkZNdEM7S0FBQUE7QUF5Rk4sZUFBZUEsSUFBSSJ9