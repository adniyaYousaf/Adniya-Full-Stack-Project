import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/index.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/home/adniya/Documents/Adniya/Adniya-Full-Stack-Project/client/src/index.css"
const __vite__css = "* {\n\tpadding: 0;\n\tmargin: 0;\n\tbox-sizing: border-box;\n}\n\nbody {\n\tbackground-color: #f1f7ed;\n\tcolor:black\n}\n\nh1 {\n\ttext-align: center;\n\tmargin-top: 1.4rem;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))